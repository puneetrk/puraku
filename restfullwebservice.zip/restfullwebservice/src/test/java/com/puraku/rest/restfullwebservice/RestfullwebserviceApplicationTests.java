package com.puraku.rest.restfullwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfullwebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
