package com.puraku.rest.restfullwebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullwebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfullwebserviceApplication.class, args);
	}

}
